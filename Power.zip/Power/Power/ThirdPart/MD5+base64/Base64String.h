//
//  MyPostMainViewController.m
//
//  Created by YTO on 13-7-17.
//  Copyright (c) 2013年 YTO—jhony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Base64String : NSObject
//@interface Utility : NSObject {
//    
//}
+ (NSString*)encodeBase64:(NSString*)input;
+ (NSString*)URLencode:(NSString *)originalString stringEncoding:(NSStringEncoding)stringEncoding;
@end
