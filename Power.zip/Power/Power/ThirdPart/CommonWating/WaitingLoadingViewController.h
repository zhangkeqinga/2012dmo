//
//  WaitingLoadingViewController.h
//  YTongExpress
//
//  Created by Kang Pengcheng on 13-1-8.
//  Copyright (c) 2013年 wuxiaozhen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundedImgClass.h"

@interface WaitingLoadingViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (strong, nonatomic) IBOutlet UIImageView *activityImage;

-(void) hiddenWaitingLoadingView;
@end
