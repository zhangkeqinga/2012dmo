//
//  AddImageVC.h
//  Power
//
//  Created by mac on 15/9/19.
//  Copyright (c) 2015年 huiwei. All rights reserved.
//

#import "BasedAFNetworkController.h"

@interface AddImageVC : BasedAFNetworkController

@end
