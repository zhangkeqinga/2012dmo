//
//  MoreViewController.h
//  Bull
//
//  Created by Grant on 15/3/19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BasedViewController.h"
#import "EScrollerView.h"

#import "PersionInfoController.h"
#import "MedicalViewController.h"
//#import "MedicalInfoController.h"
//#import "MedicalAddController.h"
#import "ChangePasswordController.h"
#import "AppointlistController.h"

@interface MoreViewController : BasedViewController<EScrollerViewDelegate>
{
//    CGRect keyboardBounds;
//    BOOL keyboardIsShowing;
//    CGFloat keyboardHeight;

}

@end
