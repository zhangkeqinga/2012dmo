//
//  AppointMode.m
//  Power
//
//  Created by mac on 15/9/20.
//  Copyright (c) 2015年 huiwei. All rights reserved.
//

#import "AppointMode.h"

@implementation AppointMode

@synthesize name;
@synthesize age;
@synthesize phone;
@synthesize departments;
@synthesize illInfo;

@end
