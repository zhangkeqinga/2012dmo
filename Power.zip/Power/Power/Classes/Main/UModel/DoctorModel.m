//
//  DoctorModel.m
//  Bull
//
//  Created by mac on 15/8/16.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "DoctorModel.h"

@implementation DoctorModel

@synthesize doctorid;
@synthesize position;
@synthesize doctorName;
@synthesize doctorDepartment;
@synthesize doctorRank;
@synthesize doctorHosipital;
@synthesize doctorProfessional;
@synthesize typeTag;
@synthesize doctorIntroduce;
@synthesize doctorSpecialty;

@end
