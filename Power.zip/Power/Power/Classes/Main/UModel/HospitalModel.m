//
//  HospitalModel.m
//  Power
//
//  Created by mac on 15/9/26.
//  Copyright (c) 2015年 huiwei. All rights reserved.
//

#import "HospitalModel.h"

@implementation HospitalModel

@synthesize createIp;
@synthesize createTime;
@synthesize createUser;
@synthesize createUserName;
@synthesize hospitalAddress;
@synthesize hospitalArea;
@synthesize hospitalCity;
@synthesize hospitalImage;
@synthesize hospitalLevel;
@synthesize hospitalName;
@synthesize hospitalNational;
@synthesize hospitalProvince;
@synthesize hospitalUrl;
@synthesize i_id;
@synthesize isDelete;
@synthesize order;
@synthesize page;
@synthesize rows;
@synthesize sort;
@synthesize updateIp;
@synthesize updateTime;
@synthesize updateUser;
@synthesize updateUserName;

@end


//{
//    createIp = "<null>";
//    createTime = "2015-09-06 16:19:04.444";
//    createUser = "<null>";
//    createUserName = "<null>";
//    hospitalAddress = "\U5b89\U5fbd\U7701\U592a\U548c\U53bf\U5065\U5eb7\U8def21\U53f7";
//    hospitalArea = "\U592a\U548c\U53bf";
//    hospitalCity = "\U868c\U57e0\U5e02";
//    hospitalImage = "http://www.jinbull.com/image/app/hospital/\U592a\U548c\U53bf\U4e2d\U533b\U9662.png";
//    hospitalLevel = 208;
//    hospitalName = "\U592a\U548c\U53bf\U4e2d\U533b\U9662";
//    hospitalNational = "\U4e2d\U56fd";
//    hospitalProvince = "\U5b89\U5fbd\U7701";
//    hospitalUrl = "http://www.thzyy.com/welcome/index.php";
//    id = 4;
//    isDelete = 0;
//    order = "<null>";
//    page = "<null>";
//    rows = "<null>";
//    sort = "<null>";
//    updateIp = "<null>";
//    updateTime = "<null>";
//    updateUser = "<null>";
//    updateUserName = "<null>";
//}
