//
//  AppointMode.h
//  Power
//
//  Created by mac on 15/9/20.
//  Copyright (c) 2015年 huiwei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppointMode : NSObject

@property (nonatomic,strong) NSString *name;       
@property (nonatomic,strong) NSString *age;        
@property (nonatomic,strong) NSString *phone;      
@property (nonatomic,strong) NSString *departments;
@property (nonatomic,strong) NSString *illInfo;


@end
