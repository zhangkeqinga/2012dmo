//
//  SettingController.h
//  BGPreferentialShare
//
//  Created by Dong on 15-3-19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "BasedViewController.h"

@interface SettingController : BasedViewController

@end
