//
//  MyAccountController.h
//  Bull
//
//  Created by Dong on 15/6/16.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BasedViewController.h"

@interface MyAccountController : BasedViewController

@end
