//
//  RewardViewController.h
//  Bull
//
//  Created by mac on 15/7/5.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "BasedViewController.h"

@interface RewardViewController : BasedViewController

@end
