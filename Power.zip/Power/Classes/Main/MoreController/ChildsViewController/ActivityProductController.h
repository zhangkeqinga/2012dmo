//
//  ActivityProductController.h
//  BGPreferentialShare
//
//  Created by Dong on 15-3-19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//
// 活动专区
#import "BasedViewController.h"

@interface ActivityProductController : BasedViewController

@end
