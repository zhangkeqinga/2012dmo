//
//  ReleaseTrailerController.h
//  BGPreferentialShare
//
//  Created by Dong on 15-3-19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//
//产品预报
#import "BasedViewController.h"

@interface ReleaseTrailerController : BasedViewController

@end
