//
//  FirendAddController.h
//  BGPreferentialShare
//
//  Created by Dong on 15-3-19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//
//添加好友
#import "BasePresentViewController.h"
#import "BasedViewController.h"

@interface FirendAddController : BasedViewController

@end
