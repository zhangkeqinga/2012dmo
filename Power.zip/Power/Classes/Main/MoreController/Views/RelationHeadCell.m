//
//  RelationHeadCell.m
//  Bull
//
//  Created by mac on 15/7/18.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "RelationHeadCell.h"

@implementation RelationHeadCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
