//
//  MessageCell.h
//  BGPreferentialShare
//
//  Created by Grant on 15/2/4.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageCell : UITableViewCell
@property (nonatomic ,strong)IBOutlet UIImageView *imgs;
@property (nonatomic ,strong)IBOutlet UILabel *titles;
@property (nonatomic ,strong)IBOutlet UILabel *versions;

@property (nonatomic ,strong)IBOutlet UIButton *moreBtn;

@end

