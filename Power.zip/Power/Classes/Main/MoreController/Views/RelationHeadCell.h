//
//  RelationHeadCell.h
//  Bull
//
//  Created by mac on 15/7/18.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelationHeadCell : UITableViewCell

@end
