//
//  MessageCell.m
//  BGPreferentialShare
//
//  Created by Grant on 15/2/4.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "MessageCell.h"

@implementation MessageCell

@synthesize imgs;
@synthesize titles;
@synthesize versions;

@synthesize moreBtn;

@end
