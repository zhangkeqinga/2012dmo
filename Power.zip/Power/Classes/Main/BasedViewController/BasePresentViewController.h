//
//  BasePresentViewController.h
//  BGPreferentialShare
//
//  Created by Dong on 15-3-19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

//使用 present  模态
#import "BasedViewController.h"

@interface BasePresentViewController : BasedViewController

@end
