//
//  UrlParamModel.m
//  YTongExpress
//
//  Created by yto on 14-11-6.
//  Copyright (c) 2014年 wuxiaozhen. All rights reserved.
//

#import "UrlParamModel.h"

@implementation UrlParamModel

@synthesize url;
@synthesize open_appkey;
@synthesize secret_key;
@synthesize app_key;
@synthesize onlineTime;
@end
