//
//  dataModel.m
//  MDBClient
//
//  Created by YTO on 13-7-29.
//  Copyright (c) 2013年 YTO—jhony. All rights reserved.
//

#import "dataModel.h"

@implementation dataModel
@synthesize createTime,msgContent,msgTitle,sendMsgType;
@end
