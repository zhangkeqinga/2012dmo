//
//  AppoinDocController.h
//  PowerfullDoctors
//
//  Created by mac on 15/9/3.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "BasedAFNetworkController.h"

@interface AppoinDocController : BasedAFNetworkController

@end
