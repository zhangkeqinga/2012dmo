//
//  UserInfo.m
//  Pods
//
//  Created by Grant on 15/3/20.
//
//

#import "UserInfo.h"


@implementation UserInfo


@end
