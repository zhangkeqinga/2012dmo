//
//  BankModel.m
//  Bull
//
//  Created by mac on 15/7/11.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "BankModel.h"

@implementation BankModel

@synthesize bankAddress;
@synthesize bankBranch;
@synthesize bankCard;
@synthesize bankIdCard;
@synthesize bankName;
@synthesize bankUserName;
@synthesize bankUserPhone;
@synthesize createTime;
@synthesize createUser;
@synthesize i_id;
@synthesize uid;
@synthesize updateTime;
@synthesize isBound;

@synthesize allPermiss;
@synthesize dayPermiss;

@end
