//
//  NotificationModel.m
//  Bull
//
//  Created by mac on 15/7/19.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "NotificationModel.h"

@implementation NotificationModel

@synthesize titles;       //->标题
@synthesize introduction; //->内容
@synthesize imagePath;    //->图片
@synthesize times;    //

@end
