//
//  FuncationModel.m
//  Bull
//
//  Created by Dong on 15/6/14.
//  Copyright (c) 2015年 Grant. All rights reserved.
//


#import "FuncationModel.h"

@implementation FuncationModel

@synthesize funName;
@synthesize funTag;
@synthesize funImg;
@synthesize funUrl;
@synthesize funTime;
@synthesize funType;

@end
