//
//  UserInfo.h
//  Pods
//
//  Created by Grant on 15/3/20.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface UserInfo : NSManagedObject



@end
