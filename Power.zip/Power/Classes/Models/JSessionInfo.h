


//#import  "SocketManager.h"



@interface JSessionInfo : NSObject{
    
    
}

+ (JSessionInfo *)sharedInstance;

@property(nonatomic,retain)NSString *secretNum;
@end




















