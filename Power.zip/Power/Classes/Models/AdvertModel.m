//
//  AdvertModel.m
//  Bull
//
//  Created by mac on 15/7/23.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "AdvertModel.h"

@implementation AdvertModel

@synthesize i_id;//(广告id)、
@synthesize imageUrl;//(图片地址)
@synthesize imageLabel;//(图片标签),
@synthesize startDate;//(活动开始时间)
@synthesize endDate;//(活动结束时间)
@synthesize linkUrl;//(网页地址)

@end
