//
//  MJPassWordRemindView.h
//  Bull
//
//  Created by Dong on 15-4-1.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import "MJPasswordView.h"

@interface MJPassWordRemindView : MJPasswordView

@end
