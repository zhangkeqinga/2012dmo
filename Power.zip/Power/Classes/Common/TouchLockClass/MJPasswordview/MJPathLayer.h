//
//  MJPathLayer.h
//  MJPasswordView
//
//  Created by tenric on 13-6-30.
//  Copyright (c) 2013年 tenric. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@class MJPasswordView;

@interface MJPathLayer : CALayer

@property (nonatomic,assign) MJPasswordView* passwordView;
@property (nonatomic,assign) double lineWidth;

@end
