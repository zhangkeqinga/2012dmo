//
//  QZScrollview.h
//  Bull
//
//  Created by mac on 15/7/11.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QZScrollview : UIScrollView

@end
