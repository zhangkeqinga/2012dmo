//
//  NavigationController.h
//  Bull
//
//  Created by Grant on 15/3/24.
//  Copyright (c) 2015年 Grant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController

@end
